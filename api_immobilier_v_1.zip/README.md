https://blog.quickadminpanel.com/laravel-api-documentation-with-openapiswagger/
php artisan l5-swagger:generate
